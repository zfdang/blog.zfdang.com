Description:
The iLO 4 firmware contained in this zip file is a modified version of the current firmware version 1.32 that reduces the Microserver Gen8 main fan speed by 40% when the server is configured to a SATA mode where iLO 4 is unable to read drives temperatures. 

Disclaimer:
Use at your own risk. This iLO 4 version 1.32 file is NOT officially supported by HP.
Without proper cooling, drives could fail prematurely and you could lose data. I will not be responsible if your hard drives and/or SSDs in your Microserver Gen8 begin to overheat due to lack of air flow. You will be responsible for monitoring your drives temperatures from the OS. 
Do Not install this firmware on other ProLiant Gen8 server models. The fix in this firmware is hardcoded to work only on the Microserver Gen8. This version won't change fan speeds on other ProLiant server models.

By unpacking the zip file and installing the iLO4_132_MicroServer.bin file, you have agreed to the above terms.

How to install this firmware:
- Log into iLO 4 webIU.
- Click on Administration on the left pane then click on Firmware.
- Press the "Browse" button and navigate to the folder where you unpacked the iLO4_132_Microserver.bin file.
- Click the "Flash" button.
- Wait until the firmware flash process completes. Be patient, it can take several minutes to finish.

